echo off
echo After the program has loaded, there may be a short delay 
echo before the program begins.
main
